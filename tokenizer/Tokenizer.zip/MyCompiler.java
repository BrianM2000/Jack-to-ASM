import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.ArrayList;
import java.io.*;
import java.util.Scanner;

public class MyCompiler{
    Scanner sc;
    int lineNum = 0;
    int depth = 0;
    String toReturn = "";
    String curLine = "";
    
    public MyCompiler(File file){
        try {
            sc = new Scanner(file);

        }
        catch (Exception ex){
            System.out.println(ex.toString());
        }
    }
    
    public String compile(){
        next();
        if(curLine.startsWith("<tokens>")){
            next();
            if(curLine.startsWith("<keyword>class</keyword>")){
                append("<class>\n");
                compileClass();
                append("</class>\n");
            }
            else{
                System.out.println("Error at line " + Integer.toString(lineNum) + " " + curLine);
            }
        }
        return toReturn;
    }
    
    public void compileClass(){
        ++depth;
        next();
        compileIdentifier();
        next();
        compileSymbol("{");
        next();
        while(curLine.contains("static") || curLine.contains("field")){
            compileClassVarDec();
            next();
        }

        while(curLine.contains("constructor") || curLine.contains("function") || curLine.contains("method")){
            compileSubroutineDec();
            next();
        }
        compileSymbol("}");
        --depth;
    }

   public void compileKeyword(){
       if(curLine.startsWith("<keyword>")){
            append(curLine + "\n");
        }
        else{
            System.out.println("Error at line " + Integer.toString(lineNum) + " " + curLine + " should be keyword");
        }
   }
    
    public void compileIdentifier(){
        if(curLine.startsWith("<identifier>")){
            append(curLine + "\n");
        }
        else{
            System.out.println("Error at line " + Integer.toString(lineNum) + " " + curLine + " should be Identifier");
        }
    }
    
    public void compileSymbol(String symbol){
        if(curLine.contains("<symbol>" + symbol + "</symbol>")){
            append(curLine + "\n");
        }
        else{
            System.out.println("Error at line " + Integer.toString(lineNum) + " " + curLine + " should be Symbol " + symbol);
        }
    }
    
    public void compileSymbol(){
        if(curLine.contains("<symbol>")){
            append(curLine + "\n");
        }
        else{
            System.out.println("Error at line " + Integer.toString(lineNum) + " " + curLine + " should be Syboml");
        }
    }

    public void compileIntConstant(){
        if(curLine.contains("<intConstant>")){
            append(curLine + "\n");
        }
        else{
            System.out.println("Error at line " + Integer.toString(lineNum) + " " + curLine + " should be intConstant");
        }
    }
    
    public void compileString(){
        if(curLine.contains("<string>")){
            append(curLine + "\n");
        }
        else{
            System.out.println("Error at line " + Integer.toString(lineNum) + " " + curLine + " should be string");
        }
    }
    
    public void compileClassVarDec(){
        append("<ClassVarDec>\n");
        ++depth;
        append(curLine + "\n");
        next();
        compileType();
        next();
        while(curLine.startsWith("<identifier>")){
            compileIdentifier();
            next();
            if(curLine.contains(",")){
                compileSymbol(",");
                next();
            }
        }
        compileSymbol(";");
        --depth;
        append("</ClassVarDec>\n");
    }

    public void compileType(){
        if(curLine.startsWith("<keyword>")){
            compileKeyword();
        }
        
        else if (curLine.startsWith("<identifier>")){
            compileIdentifier();
        }
        else{
            System.out.println("Error at line " + Integer.toString(lineNum) + " " + curLine);
        }
    }
    
    public void compileSubroutineDec(){
        append("<SubroutineDec>\n");
        ++depth;
        append(curLine + "\n");
        next();
        if(curLine.contains("void")){
            compileKeyword();
        }
        else{
            compileType();
        }
        next();
        compileIdentifier();
        next();
        compileSymbol("(");
        //next steps compileParameterList(), ')', subroutineBody
        next();
        if(curLine.contains("int") || curLine.contains("char") || curLine.contains("boolean") || curLine.contains("<identifier>")){
            compileParameterList();
        }
        compileSymbol(")");
        next();
        compileSubroutineBody();
        
        --depth;
        append("</SubroutineDec>\n");
    }
    
    public void compileParameterList(){
        append("</ParameterList>\n");
        ++depth;
        
        compileType();
        next();
        compileIdentifier();
        next();
        while(curLine.contains(",")){
            compileSymbol(",");
            next();
            compileType();
            next();
            compileIdentifier();
            next();
        }
        --depth;
        append("</ParameterList>\n");
    }

    public void compileSubroutineBody(){
        append("<SubroutineBody>\n");
        ++depth;
        compileSymbol("{");
        next();
        while(curLine.contains("var")){
            compileVarDec();
        }
        compileStatements();
        next();
        compileSymbol("}");
        --depth;
        append("</SubroutineBody>\n");
    }
    
    public void compileVarDec(){
        append("<VarDec>\n");
        ++depth;
        append(curLine + "\n");
        next();
        compileType();
        next();
        compileIdentifier();
        next();
        while(curLine.contains(",")){
            compileSymbol(",");
            next();
            compileIdentifier();
            next();
        }
        compileSymbol(";");
        next();
        --depth;
        append("</VarDec>\n");
    }
    
    public void compileStatements(){
        append("<Statements>\n");
        ++depth;
        while(curLine.contains("let") || curLine.contains("if") || curLine.contains("while")
        || curLine.contains("do") || curLine.contains("return")){
            if(curLine.contains("let")){
                compileLetStatement();
            }
            else if(curLine.contains("if")){
                compileIfStatement();
            }
            else if(curLine.contains("while")){
                compileWhileStatement();
            }
            else if(curLine.contains("do")){
                compileDoStatement();
            }
            else if(curLine.contains("return")){
                compileReturnStatement();
            }
            //System.out.println(curLine);
        }
        --depth;
        append("</Statements>\n");
    }
    
    public void compileLetStatement(){
        append("<letStatement>\n");
        ++depth;
        append(curLine + "\n");
        next();
        compileIdentifier();
        next();
        if(curLine.contains("[")){
            compileSymbol("[");
            next();
            compileExpression();
            //next();
            compileSymbol("]");
            next();
        }
        compileSymbol("=");
        next();
        compileExpression();
        //next();
        compileSymbol(";");
        next();
        --depth;
        append("</letStatement>\n");
    }
    
    public void compileIfStatement(){
        append("<ifStatement>\n");
        ++depth;
        compileKeyword();
        next();
        compileSymbol("(");
        next();
        compileExpression();
        //next();
        compileSymbol(")");
        next();
        compileSymbol("{");
        next();
        compileStatements();
        //next();
        compileSymbol("}");
        next();
        if(curLine.contains("else")){
            compileKeyword();
            next();
            compileSymbol("{");
            next();
            compileStatements();
            //next();
            compileSymbol("}");
            next();
        }
        --depth;
        append("</ifStatement>\n");
    }
    
    public void compileWhileStatement(){
        append("<whileStatement>\n");
        ++depth;
        compileKeyword();
        next();
        compileSymbol("(");
        next();
        compileExpression();
        //next();
        compileSymbol(")");
        next();
        compileSymbol("{");
        next();
        compileStatements();
        //next();
        compileSymbol("}");
        next();
        --depth;
        append("</whileStatement>\n");
    }
    
    public void compileDoStatement(){
        append("<doStatement>\n");
        ++depth;
        compileKeyword();
        next();
        compileSubroutineCall();
        next();
        compileSymbol(";");
        next();
        --depth;
        append("</doStatement>\n");
    }
    
    public void compileReturnStatement(){
        append("<returnStatement>\n");
        ++depth;
        compileKeyword();
        next();
        //System.out.println(isTerm(curLine));
        if(isTerm(curLine)){
            compileExpression();
            //next();
        }
        compileSymbol(";");
        //next();
        --depth;
        append("</returnStatement>\n");
    }
    
    public void compileExpression(){
        append("<expression>\n");
        ++depth;
        compileTerm();
        next();
        while(curLine.contains("<symbol>+</symbol>") || curLine.contains("<symbol>-</symbol>") 
        || curLine.contains("<symbol>*</symbol>") || curLine.contains("<symbol>/</symbol>")
        || curLine.contains("<symbol>&</symbol>") || curLine.contains("<symbol>|</symbol>")
        || curLine.contains("<symbol><</symbol>") || curLine.contains("<symbol>></symbol>") 
        || curLine.contains("<symbol>=</symbol>")){
            compileOp();
            next();
            compileTerm();
            next();
        }
        --depth;
        append("</expression>\n");
    }
    
    public void compileTerm(){
        append("<term>\n");
        ++depth;
        
        if(curLine.contains("<intConstant>")){
            compileIntConstant();
        }
        else if(curLine.contains("<string>")){
            compileString();
        }
        else if(curLine.contains("<keyword>")){
            compileKeyword();
        }
        else if(curLine.contains("<identifier>")){ 
            //need to find a way to determine between subroutineCall and varName [expression]
            //compileIdentifier();
            //next();
            if(sc.hasNext("\\<symbol\\>\\[\\<\\/symbol\\>")){
                compileIdentifier();
                next();
                compileSymbol("[");
                next();
                compileExpression();
                //next();
                compileSymbol("]");
            }
            else if(sc.hasNext("\\<symbol\\>\\.\\<\\/symbol\\>") || 
                    (sc.hasNext("\\<symbol\\>\\(\\<\\/symbol\\>"))){
                compileSubroutineCall();
            }
            else{
                compileIdentifier();
            }
        }
        else if(curLine.contains("(")){
            compileSymbol("(");
            next();
            compileExpression();
            //next();
            compileSymbol(")");
        }
        else if(curLine.contains("-") || curLine.contains("~")){
            compileUnaryOp();
        }
        
        --depth;
        append("</term>\n");
    }
    
    public void compileSubroutineCall(){
        append("<subroutineCall>\n");
        ++depth;
        compileIdentifier();
        next();
        if(curLine.contains("(")){
            compileSymbol("(");
            next();
            compileExpressionList();
            compileSymbol(")");
        }
        else if(curLine.contains(".")){
            compileSymbol(".");
            next();
            compileIdentifier();
            next();
            compileSymbol("(");
            next();
            compileExpressionList();
            compileSymbol(")");
        }
            
        --depth;
        append("</subroutineCall>\n");
    }
    
    public void compileExpressionList(){
        append("<expressionList>\n");
        ++depth;
        if(isTerm(curLine)){
            compileExpression();
            //next();
            while(curLine.contains(",")){
                compileSymbol(",");
                next();
                compileExpression();
                //next();
            }
        }
        else {
            //next();
        }
        --depth;
        append("</expressionList>\n");
    }
    
    public void compileOp(){
        append("<op>\n");
        ++depth;
        compileSymbol();
        --depth;
        append("</op>\n");
    }
    
    public void compileUnaryOp(){
        append("<unaryOp>\n");
        ++depth;
        if(curLine.contains("-")){
            compileSymbol("-");
        }
        else if(curLine.contains("~")){
            compileSymbol("~");
        }
        next();
        compileTerm();
        --depth;
        append("</unaryOp>\n");
    }
    
    public void compileKeywordConstant(){
        append("<keywordConstant>\n");
        ++depth;
        compileKeyword();
        --depth;
        append("</keywordConstant>\n");
    }
    
    public boolean isTerm(String string){
        if(curLine.contains("<intConstant>") ||
        curLine.contains("<string>") ||
        curLine.contains("<keyword>") || 
        curLine.contains("<identifier>") ||
        curLine.contains("<symbol>(") ||
        curLine.contains("<symbol>-") || 
        curLine.contains("<symbol>~")){
            return true;
        }
        else return false;
    }
    
    public void append(String string){
        int i = 0;
        for(i = 0; i < depth; ++i){
            toReturn = toReturn + "    ";
        }
        toReturn = toReturn + string;
    }
    
    public void next(){
        if(sc.hasNextLine()){
            if(sc.hasNext("\\<\\/tokens\\>")){
                return;
            }
            lineNum ++;
            curLine = sc.nextLine();
        }  
    }
}
